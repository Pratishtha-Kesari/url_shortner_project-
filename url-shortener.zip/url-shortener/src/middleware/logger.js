export const logger = (message, type = "INFO") => {
  const timestamp = new Date().toISOString();
  const logEntry = `[${type}] ${timestamp} - ${message}`;
  localStorage.setItem(`log-${timestamp}`, logEntry);
};