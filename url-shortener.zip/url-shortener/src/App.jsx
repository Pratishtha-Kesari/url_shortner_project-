import { BrowserRouter as Router, Routes, Route, useParams, Navigate } from "react-router-dom";
import { useState } from "react";
import ShortenerForm from "./components/ShortenerForm";
import Statistics from "./components/Statistics";
import { Container, Typography } from "@mui/material";
import { logger } from "./middleware/logger";

const Redirector = ({ links }) => {
  const { code } = useParams();
  const match = links.find((l) => l.code === code);

  if (!match) {
    logger(`Redirection failed. Shortcode ${code} not found.`, "ERROR");
    return <Typography>Invalid or expired link.</Typography>;
  }

  if (Date.now() > match.expiry) {
    logger(`Link ${code} expired.`, "ERROR");
    return <Typography>This link has expired.</Typography>;
  }

  logger(`Redirected to ${match.url}`);
  window.location.href = match.url;
  return null;
};

const App = () => {
  const [links, setLinks] = useState([]);

  return (
    <Router>
      <Container sx={{ mt: 4 }}>
        <Typography variant="h4" gutterBottom>URL Shortener</Typography>
        <Routes>
          <Route path="/" element={<ShortenerForm onShorten={setLinks} />} />
          <Route path="/stats" element={<Statistics data={links} />} />
          <Route path="/:code" element={<Redirector links={links} />} />
          <Route path="*" element={<Navigate to="/" />} />
        </Routes>
      </Container>
    </Router>
  );
};

export default App;