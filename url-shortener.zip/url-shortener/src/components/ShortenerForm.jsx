import { useState } from "react";
import { TextField, Button, Grid } from "@mui/material";
import { logger } from "../middleware/logger";
import { generateShortcode, isValidURL } from "../utils/helpers";

const ShortenerForm = ({ onShorten }) => {
  const [inputs, setInputs] = useState([{ url: "", validity: "", custom: "" }]);

  const handleChange = (index, field, value) => {
    const updated = [...inputs];
    updated[index][field] = value;
    setInputs(updated);
  };

  const handleAddField = () => {
    if (inputs.length < 5) {
      setInputs([...inputs, { url: "", validity: "", custom: "" }]);
    }
  };

  const handleSubmit = () => {
    const shortened = inputs.map((entry) => {
      if (!isValidURL(entry.url)) {
        alert("Invalid URL");
        logger(`Invalid URL input: ${entry.url}`, "ERROR");
        return null;
      }
      const code = entry.custom || generateShortcode();
      const expiry = Date.now() + (parseInt(entry.validity) || 30) * 60000;
      return { ...entry, code, expiry };
    }).filter(Boolean);

    logger("URLs shortened successfully");
    onShorten(shortened);
  };

  return (
    <>
      {inputs.map((input, i) => (
        <Grid key={i} container spacing={2} marginBottom={2}>
          <Grid item xs={4}>
            <TextField label="Original URL" fullWidth onChange={(e) => handleChange(i, "url", e.target.value)} />
          </Grid>
          <Grid item xs={3}>
            <TextField label="Validity (min)" type="number" fullWidth onChange={(e) => handleChange(i, "validity", e.target.value)} />
          </Grid>
          <Grid item xs={3}>
            <TextField label="Custom Shortcode" fullWidth onChange={(e) => handleChange(i, "custom", e.target.value)} />
          </Grid>
        </Grid>
      ))}
      <Button variant="outlined" onClick={handleAddField}>Add URL</Button>
      <Button variant="contained" onClick={handleSubmit} sx={{ ml: 2 }}>Shorten</Button>
    </>
  );
};

export default ShortenerForm;