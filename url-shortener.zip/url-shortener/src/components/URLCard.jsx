import { Card, CardContent, Typography } from "@mui/material";

const URLCard = ({ urlData }) => (
  <Card sx={{ mb: 2 }}>
    <CardContent>
      <Typography variant="h6">Short URL: http://localhost:3000/{urlData.code}</Typography>
      <Typography>Expires At: {new Date(urlData.expiry).toLocaleString()}</Typography>
    </CardContent>
  </Card>
);

export default URLCard;