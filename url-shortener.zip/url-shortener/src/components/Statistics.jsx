import { useEffect, useState } from "react";
import { Card, CardContent, Typography } from "@mui/material";

const Statistics = ({ data }) => {
  const [clickStats, setClickStats] = useState({});

  const handleClick = (code) => {
    const stat = clickStats[code] || { count: 0, details: [] };
    stat.count++;
    stat.details.push({
      timestamp: new Date().toLocaleString(),
      source: document.referrer || "Direct",
      location: "India",
    });
    setClickStats({ ...clickStats, [code]: stat });
  };

  return (
    <>
      {data.map((item, i) => (
        <Card key={i} sx={{ mb: 2 }}>
          <CardContent>
            <Typography><strong>Original:</strong> {item.url}</Typography>
            <Typography>
              <strong>Short URL:</strong>{" "}
              <a href={item.url} onClick={() => handleClick(item.code)}>
                http://localhost:3000/{item.code}
              </a>
            </Typography>
            <Typography><strong>Expires:</strong> {new Date(item.expiry).toLocaleString()}</Typography>
            <Typography><strong>Clicks:</strong> {clickStats[item.code]?.count || 0}</Typography>
            {(clickStats[item.code]?.details || []).map((d, j) => (
              <Typography key={j}>- {d.timestamp}, {d.source}, {d.location}</Typography>
            ))}
          </CardContent>
        </Card>
      ))}
    </>
  );
};

export default Statistics;